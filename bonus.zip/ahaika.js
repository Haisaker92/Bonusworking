
     let file1Array;
let file2Array;
let file3Array;
let currentCopyIndex = 0;
let batchSize = 5000; // Thay đổi batch size thành 5000 dòng
let copyCount = 0;

function handleFileselect(event, fileNumber) {
    const file = event.target.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        if (fileNumber === 'file1') {
            file1Array = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        } else if (fileNumber === 'file2') {
            file2Array = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        } else if (fileNumber === 'file3') {
            file3Array = XLSX.utils.sheet_to_json(sheet, { header: 1 });   
        }
    };

    reader.readAsArrayBuffer(file);
}


function search() {
    let found = false;
    let table = document.getElementById("resultTable");
    table.innerHTML = "";

    if (!file1Array || !file3Array || file1Array.length === 0 || file3Array.length === 0) {
        alert("Vui lòng tải lên tệp Excel trước khi tìm kiếm.");
        return;
    }

    const bannedKeywords = [50, 20, 10, 30, "CPF黑名单", "套利玩家", 100, 200, "内部测试层级", "恶意玩家", "禁止领取优惠"];
    let displayedHyids = [];

    for (let i = 0; i < file1Array.length; i++) {
        let hyid = file1Array[i][0];
        let existsInFile3 = false;

        for (let j = 0; j < file3Array.length; j++) {
            if (hyid === file3Array[j][0]) {
                existsInFile3 = true;
                break;
            }
        }

        if (!existsInFile3 && file1Array[i][1] === "正常" && !bannedKeywords.includes(file1Array[i][2]) && file1Array[i][3] !== "" && file1Array[i][3] !== undefined) {
            let qq = file1Array[i][3];

            if (!displayedHyids.includes(hyid)) {
                let row = table.insertRow(-1);
                let cell1 = row.insertCell(0);
                let cell2 = row.insertCell(1);

                cell1.innerHTML = '="' + hyid + '"';
                cell2.innerHTML = qq;

                displayedHyids.push(hyid);
                found = true;
            }
        }
    }

    if (!found) {
        alert("Không tìm thấy dữ liệu cho các giá trị QQ đã nhập.");
    }
}




function copy() {
    let qqValues = [];
    let table = document.getElementById("resultTable");

    if (table.rows.length < 1) {
        alert("No data for copy.");
        return;
    }

    const totalRows = table.rows.length;

    for (let i = currentCopyIndex; i < Math.min(currentCopyIndex + batchSize, totalRows); i++) {
        let qq = table.rows[i].cells[1].innerText.trim();

        if (qq.length < 11) {
            qq = '0'.repeat(11 - qq.length) + qq;
        }

        qqValues.push(qq);
    }

    const textArea = document.createElement('textarea');
    textArea.value = qqValues.join('\n');
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);

    copyCount++;

    alert("Copied " + qqValues.length + " rows. Copy time : " + copyCount);

    currentCopyIndex += batchSize;

    if (currentCopyIndex >= totalRows) {
        alert("Đã sao chép toàn bộ dữ liệu.");
        currentCopyIndex = 0;
        copyCount = 0;
    }
}


function check() {
    const sstime = document.getElementById("paiddate").value;
    let kd = sstime.slice(0, 16).replace(/\D/g, "");

    function retime(kd) {
        let year = kd.slice(0, 4);
        let month = kd.slice(4, 6);
        let day = kd.slice(6, 8);
        let hour = kd.slice(8, 10);
        let min = kd.slice(10, 12);
        let formattedPaidTime = `${year}年${parseInt(month)}月${parseInt(day)}日 ${hour}:${min}`;
        return formattedPaidTime;
    }

    const paidtime = retime(kd);
    let found = false;
    let table2 = document.getElementById("resultTable2");
    table2.innerHTML = "";

    if (!file1Array || !file2Array) {
        alert("Please upload both Excel files before checking.");
        return;
    }
    for (let i = 1; i < file1Array.length; i++) {
        for (let j = 1; j < file2Array.length; j++) {
            if (file2Array[j][5] == file1Array[i][3] && file2Array[j][9] == paidtime && file2Array[j][3] >= 10) {
                let hyid = file1Array[i][0];
                let qq = file2Array[j][5];
                let amount = file2Array[j][3];
                let time = file2Array[j][9];

                table2.innerHTML += "<tr><td>" + '="' + hyid +'"' + "</td><td>" + qq + "</td><td>" + amount + "</td><td>" + time + "</td></tr>";

                found = true;
           

            }
        }
    }
    if (!found) {
        alert("No data found for QQ value input.");
    }
}


function copy2() {
    let table2 = document.getElementById("resultTable2");
    let copiedData = [];

    for (let i = 0; i < table2.rows.length; i++) {
        let memberId = table2.rows[i].cells[0].innerText;
        let amount = table2.rows[i].cells[2].innerText;
        copiedData.push(memberId + "\t" + (amount>=30? 20: amount/2) + "\t" + (amount<30? 10: 5) + "\t" + "[Bônus de Registro]"
+ "\t" + "[Bônus de Registro]");
    }

    const textArea = document.createElement('textarea');
    textArea.value = copiedData.join('\n');
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);

    alert("Copied successfully '会员账号' và '金额' From Table2.");
}

function check3() {
    let table = document.getElementById("resultTable");
    let table3 = document.getElementById("resultTable3");
    table3.innerHTML = "";

    if (!file1Array || !file2Array || !file3Array) {
        alert("Please upload all Excel files before checking.");
        return;
    }

    let file3Map = {};
    for (let e = 0; e < file3Array.length; e++) {
        let id2 = file3Array[e][0];
        file3Map[id2] = true;
    }

    let file2Map = {};
    for (let k = 0; k < file2Array.length; k++) {
        let qq2 = file2Array[k][5];
        file2Map[qq2] = true;
    }

    for (let i = 0; i < table.rows.length; i++) {
        let qq = table.rows[i].cells[1].innerText.trim();
        let id1 = table.rows[i].cells[0].innerText.trim();

        if (!(id1 in file3Map) && !(qq in file2Map)) {
            table3.innerHTML += "<tr><td>" + id1 + "</td></tr>";
        }
    }
}

function copy3() {
    let table3 = document.getElementById("resultTable3");
    let copiedData = [];

    for (let i = 0; i < table3.rows.length; i++) {
        let memberId = table3.rows[i].cells[0].innerText;
                copiedData.push(memberId + "\t" + 0.55 + "\t" + 5 + "\t" + "[Bônus de Registro]"
+ "\t" + "[Bônus de Registro]");
    }

    const textArea = document.createElement('textarea');
    textArea.value = copiedData.join('\n');
    document.body.appendChild(textArea);
    textArea.select();
    document.execCommand('copy');
    document.body.removeChild(textArea);

    alert("Copied successfully From Table3.");
}